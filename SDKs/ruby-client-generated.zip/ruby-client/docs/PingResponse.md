# SwaggerClient::PingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datetime** | **String** |  | [optional] 
**remote_ip** | **String** |  | [optional] 
**timestamp** | **Integer** |  | [optional] 
**user_agent** | **String** |  | [optional] 


