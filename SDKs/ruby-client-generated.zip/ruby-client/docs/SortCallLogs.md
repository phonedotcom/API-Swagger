# SwaggerClient::SortCallLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**start_time** | **String** |  | [optional] 
**created_at** | **String** |  | [optional] 


