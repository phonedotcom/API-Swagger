# SwaggerClient::ApplicationFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Application ID. Read-only. | [optional] 
**name** | **String** | Application name | [optional] 


