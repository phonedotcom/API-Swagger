# SwaggerClient::ListExtensions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdExtensionNameArray**](FilterIdExtensionNameArray.md) |  | [optional] 
**sort** | [**SortIdExtensionName**](SortIdExtensionName.md) |  | [optional] 
**total** | **Integer** |  | [optional] 
**offset** | **Integer** |  | [optional] 
**limit** | **Integer** |  | [optional] 
**items** | [**Array&lt;ExtensionFull&gt;**](ExtensionFull.md) |  | [optional] 


