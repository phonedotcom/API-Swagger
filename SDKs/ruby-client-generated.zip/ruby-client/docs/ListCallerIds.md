# SwaggerClient::ListCallerIds

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterNameNumberArray**](FilterNameNumberArray.md) |  | [optional] 
**sort** | [**SortNameNumber**](SortNameNumber.md) |  | [optional] 
**total** | **Integer** |  | [optional] 
**offset** | **Integer** |  | [optional] 
**limit** | **Integer** |  | [optional] 
**items** | [**Array&lt;CallerIdFull&gt;**](CallerIdFull.md) |  | [optional] 


