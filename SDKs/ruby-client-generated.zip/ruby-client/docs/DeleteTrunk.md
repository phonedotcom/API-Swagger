# SwaggerClient::DeleteTrunk

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**success** | **BOOLEAN** |  | [optional] 


