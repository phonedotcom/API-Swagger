# SwaggerClient::ScheduleSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Integer Schedule ID. Read-only. | [optional] 
**name** | **String** | Name | [optional] 


