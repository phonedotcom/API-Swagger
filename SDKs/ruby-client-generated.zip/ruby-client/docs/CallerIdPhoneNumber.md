# SwaggerClient::CallerIdPhoneNumber

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name that this number will be associated with. Must be no longer than 15 characters, and can only contain English letters, numbers, spaces, and commas. | [optional] 
**type** | **String** | Can be \&quot;business\&quot; or \&quot;personal\&quot; | [optional] 


