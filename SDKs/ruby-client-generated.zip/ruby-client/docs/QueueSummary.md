# SwaggerClient::QueueSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Integer ID. Read-only. | 
**name** | **String** | Name. Required. | 


