# SwaggerClient::MediaSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Recording ID. Read-only. | [optional] 
**name** | **String** | Name of recording | [optional] 


