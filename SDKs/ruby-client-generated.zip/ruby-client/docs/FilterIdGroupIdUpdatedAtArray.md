# SwaggerClient::FilterIdGroupIdUpdatedAtArray

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**group_id** | **String** |  | [optional] 
**updated_at** | **String** |  | [optional] 


