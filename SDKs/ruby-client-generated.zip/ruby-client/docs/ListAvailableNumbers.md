# SwaggerClient::ListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterListAvailableNumbers**](FilterListAvailableNumbers.md) |  | [optional] 
**sort** | [**SortListAvailableNumbers**](SortListAvailableNumbers.md) |  | [optional] 
**total** | **Integer** |  | [optional] 
**offset** | **Integer** |  | [optional] 
**limit** | **Integer** |  | [optional] 
**items** | [**Array&lt;AvailableNumbersFull&gt;**](AvailableNumbersFull.md) |  | [optional] 


