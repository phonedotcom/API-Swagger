# SwaggerClient::SortIdUpdatedAt

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**updated_at** | **String** |  | [optional] 


