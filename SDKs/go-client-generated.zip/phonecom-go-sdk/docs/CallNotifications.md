# CallNotifications

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Emails** | **[]string** | Array of email addresses | [optional] [default to null]
**Sms** | **string** | A phone number capable of receiving SMS messages | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


