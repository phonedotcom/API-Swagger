# PingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Datetime** | **string** |  | [optional] [default to null]
**RemoteIp** | **string** |  | [optional] [default to null]
**Timestamp** | **int32** |  | [optional] [default to null]
**UserAgent** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


