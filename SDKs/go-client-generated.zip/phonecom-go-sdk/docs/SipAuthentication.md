# SipAuthentication

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Host** | **string** | Hostname | [optional] [default to null]
**Port** | **int32** | Port number | [optional] [default to null]
**Username** | **string** | Username. This is the ID of the device. | [optional] [default to null]
**Password** | **string** | Password. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


