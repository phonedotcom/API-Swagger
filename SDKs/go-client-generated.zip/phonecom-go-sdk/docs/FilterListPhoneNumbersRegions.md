# FilterListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CountryCode** | **string** |  | [optional] [default to null]
**Npa** | **string** |  | [optional] [default to null]
**Nxx** | **string** |  | [optional] [default to null]
**IsTollFree** | **string** |  | [optional] [default to null]
**City** | **string** |  | [optional] [default to null]
**ProvincePostalCode** | **string** |  | [optional] [default to null]
**CountryPostalCode** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


