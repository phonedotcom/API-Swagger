# Member

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Extension** | [**ExtensionSummary**](ExtensionSummary.md) | Extension that this member refers to. Output is an Extension Summary Object. Input must be an Extension Lookup Object. | [optional] [default to null]
**PhoneNumber** | **string** | Phone number | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


