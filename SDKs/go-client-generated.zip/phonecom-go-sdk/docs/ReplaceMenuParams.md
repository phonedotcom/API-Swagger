# ReplaceMenuParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] [default to null]
**Greeting** | [**interface{}**](interface{}.md) |  | [optional] [default to null]
**InvalidKeypress** | [**interface{}**](interface{}.md) |  | [optional] [default to null]
**AllowExtensionDial** | **bool** |  | [optional] [default to null]
**KeypressWaitTime** | **int32** |  | [optional] [default to null]
**TimeoutHandler** | [**interface{}**](interface{}.md) |  | [optional] [default to null]
**Options** | [**[]interface{}**](interface{}.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


