# Recipient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Number** | **string** | Phone number that will receive the SMS message | [optional] [default to null]
**Status** | **string** | Indicate the status of your SMS object. May be &#39;sent&#39;, &#39;received&#39;, &#39;queued&#39;, &#39;new&#39; ... | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


