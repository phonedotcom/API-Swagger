# ListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**GroupBy** | **[]string** |  | [optional] [default to null]
**Filters** | [**FilterListPhoneNumbersRegions**](FilterListPhoneNumbersRegions.md) |  | [optional] [default to null]
**Sort** | [**SortListPhoneNumbersRegions**](SortListPhoneNumbersRegions.md) |  | [optional] [default to null]
**Total** | **int32** |  | [optional] [default to null]
**Offset** | **int32** |  | [optional] [default to null]
**Limit** | **int32** |  | [optional] [default to null]
**Items** | [**[]PhoneNumbersRegionFull**](PhoneNumbersRegionFull.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


