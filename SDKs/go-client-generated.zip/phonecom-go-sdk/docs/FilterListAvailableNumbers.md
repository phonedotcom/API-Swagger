# FilterListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PhoneNumber** | **string** |  | [optional] [default to null]
**CountryCode** | **string** |  | [optional] [default to null]
**Npa** | **string** |  | [optional] [default to null]
**Nxx** | **string** |  | [optional] [default to null]
**Xxxx** | **string** |  | [optional] [default to null]
**City** | **string** |  | [optional] [default to null]
**Province** | **string** |  | [optional] [default to null]
**Country** | **string** |  | [optional] [default to null]
**Price** | **string** |  | [optional] [default to null]
**Category** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


