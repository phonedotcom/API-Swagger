# FilterCallLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] [default to null]
**StartTime** | **string** |  | [optional] [default to null]
**CreatedAt** | **string** |  | [optional] [default to null]
**Direction** | **string** |  | [optional] [default to null]
**CalledNumber** | **string** |  | [optional] [default to null]
**Type_** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


