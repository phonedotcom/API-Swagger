# ListContacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | [**FilterIdGroupIdUpdatedAtArray**](FilterIdGroupIdUpdatedAtArray.md) |  | [optional] [default to null]
**Sort** | [**SortIdUpdatedAt**](SortIdUpdatedAt.md) |  | [optional] [default to null]
**Total** | **int32** |  | [optional] [default to null]
**Offset** | **int32** |  | [optional] [default to null]
**Limit** | **int32** |  | [optional] [default to null]
**Items** | [**[]ContactFull**](ContactFull.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


