# Line

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Line** | **int32** | Line number | [optional] [default to null]
**Extension** | [**ExtensionSummary**](ExtensionSummary.md) | Extensions object that this line number is mapped to. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


