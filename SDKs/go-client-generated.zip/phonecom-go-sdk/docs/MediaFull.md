# MediaFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Recording ID. Read-only. | [optional] [default to null]
**Name** | **string** | Name of recording | [optional] [default to null]
**Type_** | **string** | Can be hold_music or greeting. Indicates the purpose of this recording and where it can be used. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


