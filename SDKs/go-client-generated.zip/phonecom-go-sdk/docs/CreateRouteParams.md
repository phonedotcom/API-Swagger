# CreateRouteParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Name | [optional] [default to null]
**Rules** | [**[]interface{}**](interface{}.md) | Rule Sets | [optional] [default to null]
**Extension** | [**interface{}**](interface{}.md) | Extension Reference | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


