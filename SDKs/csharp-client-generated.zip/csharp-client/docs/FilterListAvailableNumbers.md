# IO.Swagger.Model.FilterListAvailableNumbers
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PhoneNumber** | **string** |  | [optional] 
**CountryCode** | **string** |  | [optional] 
**Npa** | **string** |  | [optional] 
**Nxx** | **string** |  | [optional] 
**Xxxx** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**Province** | **string** |  | [optional] 
**Country** | **string** |  | [optional] 
**Price** | **string** |  | [optional] 
**Category** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

