# IO.Swagger.Model.ReplaceMenuParams
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** |  | [optional] 
**Greeting** | **Object** |  | [optional] 
**InvalidKeypress** | **Object** |  | [optional] 
**AllowExtensionDial** | **bool?** |  | [optional] 
**KeypressWaitTime** | **int?** |  | [optional] 
**TimeoutHandler** | **Object** |  | [optional] 
**Options** | **List&lt;Object&gt;** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

