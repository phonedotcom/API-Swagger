# IO.Swagger.Model.ListSms
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | [**FilterIdDirectionFrom**](FilterIdDirectionFrom.md) |  | [optional] 
**Sort** | [**SortIdCreatedAt**](SortIdCreatedAt.md) |  | [optional] 
**Total** | **int?** |  | [optional] 
**Offset** | **int?** |  | [optional] 
**Limit** | **int?** |  | [optional] 
**Items** | [**List&lt;SmsFull&gt;**](SmsFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

