# IO.Swagger.Model.Email
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Type** | **string** | Email type, one of: primary or alternate. Default is primary. | [optional] 
**_Email** | **string** | Email address. Required. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

