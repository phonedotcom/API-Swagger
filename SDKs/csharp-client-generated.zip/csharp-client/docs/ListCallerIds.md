# IO.Swagger.Model.ListCallerIds
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | [**FilterNameNumberArray**](FilterNameNumberArray.md) |  | [optional] 
**Sort** | [**SortNameNumber**](SortNameNumber.md) |  | [optional] 
**Total** | **int?** |  | [optional] 
**Offset** | **int?** |  | [optional] 
**Limit** | **int?** |  | [optional] 
**Items** | [**List&lt;CallerIdFull&gt;**](CallerIdFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

