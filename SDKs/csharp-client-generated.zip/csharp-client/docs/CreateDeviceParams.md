# IO.Swagger.Model.CreateDeviceParams
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Device Name | [optional] 
**Lines** | **List&lt;Object&gt;** | List of line objects | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

