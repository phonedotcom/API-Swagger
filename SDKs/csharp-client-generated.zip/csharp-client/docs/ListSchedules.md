# IO.Swagger.Model.ListSchedules
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Filters** | [**FilterIdNameArray**](FilterIdNameArray.md) |  | [optional] 
**Sort** | [**SortIdName**](SortIdName.md) |  | [optional] 
**Total** | **int?** |  | [optional] 
**Offset** | **int?** |  | [optional] 
**Limit** | **int?** |  | [optional] 
**Items** | [**List&lt;ScheduleFull&gt;**](ScheduleFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

