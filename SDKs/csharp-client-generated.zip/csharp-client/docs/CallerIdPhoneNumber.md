# IO.Swagger.Model.CallerIdPhoneNumber
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Name that this number will be associated with. Must be no longer than 15 characters, and can only contain English letters, numbers, spaces, and commas. | [optional] 
**Type** | **string** | Can be \&quot;business\&quot; or \&quot;personal\&quot; | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

