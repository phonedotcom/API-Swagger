# IO.Swagger.Model.ContactAccount
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Name. Required. | [optional] 
**Company** | **string** | Company name | [optional] 
**Address** | [**Address**](Address.md) |  | [optional] 
**Phone** | **string** | Phone number. Required. | [optional] 
**Fax** | **string** | Fax number | [optional] 
**PrimaryEmail** | **string** | Primary email address. Required. | [optional] 
**AlternateEmail** | **string** | Alternate email address | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

