# IO.Swagger.Model.Line
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Line** | **int?** | Line number | [optional] 
**Extension** | [**ExtensionSummary**](ExtensionSummary.md) | Extensions object that this line number is mapped to. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

