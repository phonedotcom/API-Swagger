# IO.Swagger.Model.FilterCallLogs
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] 
**StartTime** | **string** |  | [optional] 
**CreatedAt** | **string** |  | [optional] 
**Direction** | **string** |  | [optional] 
**CalledNumber** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

