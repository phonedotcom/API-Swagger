
# CreateSubaccountParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** | Sub account password | 
**password** | **String** | Sub account password | 
**contact** | [**ContactSubaccount**](ContactSubaccount.md) | Contact Object. See below for details. |  [optional]
**billingContact** | [**ContactSubaccount**](ContactSubaccount.md) | Contact Object for billing purposes. See below for details. |  [optional]



