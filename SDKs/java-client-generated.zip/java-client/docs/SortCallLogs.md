
# SortCallLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**startTime** | **String** |  |  [optional]
**createdAt** | **String** |  |  [optional]



