
# FilterListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phoneNumber** | **String** |  |  [optional]
**countryCode** | **String** |  |  [optional]
**npa** | **String** |  |  [optional]
**nxx** | **String** |  |  [optional]
**xxxx** | **String** |  |  [optional]
**city** | **String** |  |  [optional]
**province** | **String** |  |  [optional]
**country** | **String** |  |  [optional]
**price** | **String** |  |  [optional]
**category** | **String** |  |  [optional]



