
# FilterCallLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**startTime** | **String** |  |  [optional]
**createdAt** | **String** |  |  [optional]
**direction** | **String** |  |  [optional]
**calledNumber** | **String** |  |  [optional]
**type** | **String** |  |  [optional]



