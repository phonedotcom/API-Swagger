
# CreateDeviceParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Device Name |  [optional]
**lines** | **List&lt;Object&gt;** | List of line objects |  [optional]



