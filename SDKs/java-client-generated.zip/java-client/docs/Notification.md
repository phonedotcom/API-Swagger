
# Notification

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emails** | **List&lt;String&gt;** | Array of email addresses |  [optional]
**sms** | **String** | Phone number capable of receiving SMS messages |  [optional]



