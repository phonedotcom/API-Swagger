
# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line1** | **String** | Street address line 1. Required. | 
**line2** | **String** | Street address line 2 |  [optional]
**city** | **String** | City. Required. | 
**province** | **String** | Province. Required if country is US |  [optional]
**postalCode** | **String** | Postal code |  [optional]
**country** | **String** | 2-character country code. Required. | 



