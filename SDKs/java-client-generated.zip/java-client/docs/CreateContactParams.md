
# CreateContactParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**firstName** | **String** | First Name |  [optional]
**middleName** | **String** | Middle Name |  [optional]
**lastName** | **String** | Last Name |  [optional]
**prefix** | **String** | Prefix |  [optional]
**phoneticFirstName** | **String** | Phonetic First Name |  [optional]
**phoneticMiddleName** | **String** | Phonetic Middle Name |  [optional]
**phoneticLastName** | **String** | Phonetic Last Name |  [optional]
**suffix** | **String** | Suffix |  [optional]
**nickname** | **String** | Nickname |  [optional]
**company** | **String** | Company Name |  [optional]
**department** | **String** | Department Name |  [optional]
**jobTitle** | **String** | Job Title |  [optional]
**emails** | **List&lt;Object&gt;** | Email Addresses |  [optional]
**phoneNumbers** | **List&lt;Object&gt;** | Phone Numbers |  [optional]
**addresses** | **List&lt;Object&gt;** | Addresses |  [optional]
**group** | **Object** | Contact Group |  [optional]



