# Line

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line** | **int** | Line number | [optional] 
**extension** | [**ExtensionSummary**](ExtensionSummary.md) | Extensions object that this line number is mapped to. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


