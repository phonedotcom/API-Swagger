# ListContacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdGroupIdUpdatedAtArray**](FilterIdGroupIdUpdatedAtArray.md) |  | [optional] 
**sort** | [**SortIdUpdatedAt**](SortIdUpdatedAt.md) |  | [optional] 
**total** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 
**limit** | **int** |  | [optional] 
**items** | [**list[ContactFull]**](ContactFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


