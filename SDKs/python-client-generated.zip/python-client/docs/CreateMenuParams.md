# CreateMenuParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**main_message** | **object** |  | [optional] 
**invalid_keypress_message** | **object** |  | [optional] 
**allow_extension_dial** | **bool** |  | [optional] 
**keypress_wait_time** | **int** |  | [optional] 
**timeout_handler** | **object** |  | [optional] 
**options** | **list[object]** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


