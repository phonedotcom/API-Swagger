# MediaFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **int** | Recording ID. Read-only. | [optional] 
**name** | **str** | Name of recording | [optional] 
**type** | **str** | Can be hold_music or greeting. Indicates the purpose of this recording and where it can be used. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


