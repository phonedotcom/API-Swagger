# ListPhoneNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdNamePhoneNumberArray**](FilterIdNamePhoneNumberArray.md) |  | [optional] 
**sort** | [**SortIdNamePhoneNumber**](SortIdNamePhoneNumber.md) |  | [optional] 
**total** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 
**limit** | **int** |  | [optional] 
**items** | [**list[PhoneNumberContact]**](PhoneNumberContact.md) | Array of Contact Phone Number Objects. See below for details. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


