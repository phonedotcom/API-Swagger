# FilterCallLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **string** |  | [optional] 
**start_time** | **string** |  | [optional] 
**created_at** | **string** |  | [optional] 
**direction** | **string** |  | [optional] 
**called_number** | **string** |  | [optional] 
**type** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


