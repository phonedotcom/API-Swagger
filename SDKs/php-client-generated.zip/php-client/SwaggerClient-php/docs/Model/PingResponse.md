# PingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datetime** | **string** |  | [optional] 
**remote_ip** | **string** |  | [optional] 
**timestamp** | **int** |  | [optional] 
**user_agent** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


