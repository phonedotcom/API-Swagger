# ListCallLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**\Swagger\Client\Model\FilterCallLogs**](FilterCallLogs.md) |  | [optional] 
**sort** | [**\Swagger\Client\Model\SortCallLogs**](SortCallLogs.md) |  | [optional] 
**total** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 
**limit** | **int** |  | [optional] 
**items** | [**\Swagger\Client\Model\CallLogFull[]**](CallLogFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


