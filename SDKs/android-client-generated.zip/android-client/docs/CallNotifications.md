
# CallNotifications

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emails** | **List&lt;String&gt;** | Array of email addresses |  [optional]
**sms** | **String** | A phone number capable of receiving SMS messages |  [optional]



