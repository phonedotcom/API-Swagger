
# ExpressServiceCodeFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | ID |  [optional]
**expressServiceCode** | **String** | An 8-digit number in string format |  [optional]
**expireDate** | **Integer** | UNIX time stamp representing the UTC time that the Express Service Code expires. Please note that every time this service is executed, the expire_date is set to now + 24 hours. |  [optional]



