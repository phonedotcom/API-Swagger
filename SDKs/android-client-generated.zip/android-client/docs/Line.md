
# Line

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line** | **Integer** | Line number |  [optional]
**extension** | [**ExtensionSummary**](ExtensionSummary.md) | Extensions object that this line number is mapped to. |  [optional]



