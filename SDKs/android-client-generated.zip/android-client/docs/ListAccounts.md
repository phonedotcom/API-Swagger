
# ListAccounts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdArray**](FilterIdArray.md) |  |  [optional]
**sort** | [**SortId**](SortId.md) |  |  [optional]
**total** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**limit** | **Integer** |  |  [optional]
**items** | [**List&lt;AccountFull&gt;**](AccountFull.md) |  |  [optional]



