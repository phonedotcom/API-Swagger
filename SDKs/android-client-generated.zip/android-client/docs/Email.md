
# Email

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Email type, one of: primary or alternate. Default is primary. |  [optional]
**email** | **String** | Email address. Required. |  [optional]



