
# CallerIdFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **String** | Phone number, in E.164 format |  [optional]
**name** | **String** | Name you have supplied for this number |  [optional]
**type** | **String** | Type of Caller ID. account means this number is registered to your account, and extra refers to extra numbers which you have authorized, which are not managed under Phone.com. |  [optional]



