
# FilterIdGroupIdUpdatedAtArray

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**groupId** | **String** |  |  [optional]
**updatedAt** | **String** |  |  [optional]



