
# PingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datetime** | **String** |  |  [optional]
**remoteIp** | **String** |  |  [optional]
**timestamp** | **Integer** |  |  [optional]
**userAgent** | **String** |  |  [optional]



