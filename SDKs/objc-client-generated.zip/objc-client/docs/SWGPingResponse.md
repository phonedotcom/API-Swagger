# SWGPingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datetime** | **NSString*** |  | [optional] 
**remoteIp** | **NSString*** |  | [optional] 
**timestamp** | **NSNumber*** |  | [optional] 
**userAgent** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


