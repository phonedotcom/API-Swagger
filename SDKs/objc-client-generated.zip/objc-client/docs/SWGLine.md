# SWGLine

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line** | **NSNumber*** | Line number | [optional] 
**extension** | [**SWGExtensionSummary***](SWGExtensionSummary.md) | Extensions object that this line number is mapped to. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


