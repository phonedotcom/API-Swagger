# SWGSortListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**countryCode** | **NSString*** |  | [optional] 
**npa** | **NSString*** |  | [optional] 
**nxx** | **NSString*** |  | [optional] 
**isTollFree** | **NSString*** |  | [optional] 
**city** | **NSString*** |  | [optional] 
**provincePostalCode** | **NSString*** |  | [optional] 
**countryPostalCode** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


