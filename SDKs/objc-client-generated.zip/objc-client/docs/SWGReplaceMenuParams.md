# SWGReplaceMenuParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **NSString*** |  | [optional] 
**greeting** | **NSObject*** |  | [optional] 
**invalidKeypress** | **NSObject*** |  | [optional] 
**allowExtensionDial** | **NSNumber*** |  | [optional] 
**keypressWaitTime** | **NSNumber*** |  | [optional] 
**timeoutHandler** | **NSObject*** |  | [optional] 
**options** | **NSArray&lt;NSObject*&gt;*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


