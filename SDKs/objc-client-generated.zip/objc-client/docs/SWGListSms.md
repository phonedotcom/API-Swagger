# SWGListSms

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**SWGFilterIdDirectionFrom***](SWGFilterIdDirectionFrom.md) |  | [optional] 
**sort** | [**SWGSortIdCreatedAt***](SWGSortIdCreatedAt.md) |  | [optional] 
**total** | **NSNumber*** |  | [optional] 
**offset** | **NSNumber*** |  | [optional] 
**limit** | **NSNumber*** |  | [optional] 
**items** | [**NSArray&lt;SWGSmsFull&gt;***](SWGSmsFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


