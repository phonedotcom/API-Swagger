# SWGSipAuthentication

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**host** | **NSString*** | Hostname | [optional] 
**port** | **NSNumber*** | Port number | [optional] 
**username** | **NSString*** | Username. This is the ID of the device. | [optional] 
**password** | **NSString*** | Password. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


