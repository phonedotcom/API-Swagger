# SWGListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupBy** | **NSArray&lt;NSString*&gt;*** |  | [optional] 
**filters** | [**SWGFilterListPhoneNumbersRegions***](SWGFilterListPhoneNumbersRegions.md) |  | [optional] 
**sort** | [**SWGSortListPhoneNumbersRegions***](SWGSortListPhoneNumbersRegions.md) |  | [optional] 
**total** | **NSNumber*** |  | [optional] 
**offset** | **NSNumber*** |  | [optional] 
**limit** | **NSNumber*** |  | [optional] 
**items** | [**NSArray&lt;SWGPhoneNumbersRegionFull&gt;***](SWGPhoneNumbersRegionFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


