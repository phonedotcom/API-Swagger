# SWGDeviceMembership

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line** | **NSNumber*** | Line number to which this extension is assigned. Integer. | [optional] 
**device** | [**SWGDeviceSummary***](SWGDeviceSummary.md) | Device that this extension belongs to. Output is an Device Summary Object. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


