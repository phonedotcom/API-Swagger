# FilterListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone_number** | **string** |  | [optional] 
**country_code** | **string** |  | [optional] 
**npa** | **int** |  | [optional] 
**nxx** | **string** |  | [optional] 
**xxxx** | **string** |  | [optional] 
**city** | **string** |  | [optional] 
**province** | **string** |  | [optional] 
**country** | **string** |  | [optional] 
**price** | **string** |  | [optional] 
**category** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


