# Member

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**extension** | [**\Swagger\Client\Model\ExtensionSummary**](ExtensionSummary.md) | Extension that this member refers to. Output is an Extension Summary Object. Input must be an Extension Lookup Object. | [optional] 
**phone_number** | **string** | Phone number | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


