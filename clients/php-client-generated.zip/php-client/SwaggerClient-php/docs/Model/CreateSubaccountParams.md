# CreateSubaccountParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **string** | Sub account password | 
**password** | **string** | Sub account password | 
**contact** | [**\Swagger\Client\Model\ContactSubaccount**](ContactSubaccount.md) | Contact Object. See below for details. | [optional] 
**billing_contact** | [**\Swagger\Client\Model\ContactSubaccount**](ContactSubaccount.md) | Contact Object for billing purposes. See below for details. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


