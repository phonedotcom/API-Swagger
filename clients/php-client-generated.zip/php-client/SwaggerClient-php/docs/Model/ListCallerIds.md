# ListCallerIds

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**\Swagger\Client\Model\FilterNameNumberArray**](FilterNameNumberArray.md) |  | [optional] 
**sort** | [**\Swagger\Client\Model\SortNameNumber**](SortNameNumber.md) |  | [optional] 
**total** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 
**limit** | **int** |  | [optional] 
**items** | [**\Swagger\Client\Model\CallerIdFull[]**](CallerIdFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


