# ListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_by** | **string[]** |  | [optional] 
**filters** | [**\Swagger\Client\Model\FilterListPhoneNumbersRegions**](FilterListPhoneNumbersRegions.md) |  | [optional] 
**sort** | [**\Swagger\Client\Model\SortListPhoneNumbersRegions**](SortListPhoneNumbersRegions.md) |  | [optional] 
**total** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 
**limit** | **int** |  | [optional] 
**items** | [**\Swagger\Client\Model\PhoneNumbersRegionFull[]**](PhoneNumbersRegionFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


