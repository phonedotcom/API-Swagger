# FilterListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country_code** | **string** |  | [optional] 
**npa** | **string** |  | [optional] 
**nxx** | **string** |  | [optional] 
**is_toll_free** | **string** |  | [optional] 
**city** | **string** |  | [optional] 
**province_postal_code** | **string** |  | [optional] 
**country_postal_code** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


