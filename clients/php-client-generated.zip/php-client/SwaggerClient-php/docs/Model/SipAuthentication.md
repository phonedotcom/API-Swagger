# SipAuthentication

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**host** | **string** | Hostname | [optional] 
**port** | **int** | Port number | [optional] 
**username** | **string** | Username. This is the ID of the device. | [optional] 
**password** | **string** | Password. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


