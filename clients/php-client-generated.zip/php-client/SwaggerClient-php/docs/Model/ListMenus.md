# ListMenus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**\Swagger\Client\Model\FilterIdNameArray**](FilterIdNameArray.md) |  | [optional] 
**sort** | [**\Swagger\Client\Model\SortIdName**](SortIdName.md) |  | [optional] 
**total** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 
**limit** | **int** |  | [optional] 
**items** | [**\Swagger\Client\Model\MenuFull[]**](MenuFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


