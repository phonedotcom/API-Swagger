# SwaggerClient::ListPhoneNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdNamePhoneNumberArray**](FilterIdNamePhoneNumberArray.md) |  | [optional] 
**sort** | [**SortIdNamePhoneNumber**](SortIdNamePhoneNumber.md) |  | [optional] 
**total** | **Integer** |  | [optional] 
**offset** | **Integer** |  | [optional] 
**limit** | **Integer** |  | [optional] 
**items** | [**Array&lt;PhoneNumberContact&gt;**](PhoneNumberContact.md) | Array of Contact Phone Number Objects. See below for details. | [optional] 


