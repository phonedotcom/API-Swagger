# SwaggerClient::SipAuthentication

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**host** | **String** | Hostname | [optional] 
**port** | **Integer** | Port number | [optional] 
**username** | **String** | Username. This is the ID of the device. | [optional] 
**password** | **String** | Password. | [optional] 


