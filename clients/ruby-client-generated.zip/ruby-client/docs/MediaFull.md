# SwaggerClient::MediaFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Recording ID. Read-only. | [optional] 
**name** | **String** | Name of recording | [optional] 
**type** | **String** | Can be hold_music or greeting. Indicates the purpose of this recording and where it can be used. | [optional] 


