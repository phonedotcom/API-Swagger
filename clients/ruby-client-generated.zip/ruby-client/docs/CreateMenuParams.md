# SwaggerClient::CreateMenuParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**main_message** | **Object** |  | [optional] 
**invalid_keypress_message** | **Object** |  | [optional] 
**allow_extension_dial** | **BOOLEAN** |  | [optional] 
**keypress_wait_time** | **Integer** |  | [optional] 
**timeout_handler** | **Object** |  | [optional] 
**options** | **Array&lt;Object&gt;** |  | [optional] 


