# SwaggerClient::FilterIdNamePhoneNumberArray

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**phone_number** | **String** |  | [optional] 


