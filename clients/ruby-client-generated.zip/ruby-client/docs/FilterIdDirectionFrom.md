# SwaggerClient::FilterIdDirectionFrom

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**direction** | **String** |  | [optional] 
**from** | **String** |  | [optional] 


