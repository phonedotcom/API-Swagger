# SwaggerClient::CreateRouteParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name | [optional] 
**rules** | **Array&lt;Object&gt;** | Rule Sets | [optional] 
**extension** | **Object** | Extension Reference | [optional] 


