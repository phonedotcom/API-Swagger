# SwaggerClient::FilterListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone_number** | **String** |  | [optional] 
**country_code** | **String** |  | [optional] 
**npa** | **Integer** |  | [optional] 
**nxx** | **String** |  | [optional] 
**xxxx** | **String** |  | [optional] 
**city** | **String** |  | [optional] 
**province** | **String** |  | [optional] 
**country** | **String** |  | [optional] 
**price** | **String** |  | [optional] 
**category** | **String** |  | [optional] 


