# SwaggerClient::TrunkSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Integer Trunk ID. Read-only. | 
**name** | **String** | Name. Required. | 


