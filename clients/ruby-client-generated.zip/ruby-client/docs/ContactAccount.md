# SwaggerClient::ContactAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name. Required. | [optional] 
**company** | **String** | Company name | [optional] 
**address** | [**Address**](Address.md) |  | [optional] 
**phone** | **String** | Phone number. Required. | [optional] 
**fax** | **String** | Fax number | [optional] 
**primary_email** | **String** | Primary email address. Required. | [optional] 
**alternate_email** | **String** | Alternate email address | [optional] 


