# SwaggerClient::FilterCallLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**start_time** | **String** |  | [optional] 
**created_at** | **String** |  | [optional] 
**direction** | **String** |  | [optional] 
**called_number** | **String** |  | [optional] 
**type** | **String** |  | [optional] 


