# SwaggerClient::Member

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**extension** | [**ExtensionSummary**](ExtensionSummary.md) | Extension that this member refers to. Output is an Extension Summary Object. Input must be an Extension Lookup Object. | [optional] 
**phone_number** | **String** | Phone number | [optional] 


