# SwaggerClient::ReplaceMenuParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**greeting** | **Object** |  | [optional] 
**invalid_keypress** | **Object** |  | [optional] 
**allow_extension_dial** | **BOOLEAN** |  | [optional] 
**keypress_wait_time** | **Integer** |  | [optional] 
**timeout_handler** | **Object** |  | [optional] 
**options** | **Array&lt;Object&gt;** |  | [optional] 


