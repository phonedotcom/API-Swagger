# SwaggerClient::DeviceMembership

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**line** | **Integer** | Line number to which this extension is assigned. Integer. | [optional] 
**device** | [**DeviceSummary**](DeviceSummary.md) | Device that this extension belongs to. Output is an Device Summary Object. | [optional] 


