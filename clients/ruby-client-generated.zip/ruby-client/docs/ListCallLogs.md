# SwaggerClient::ListCallLogs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterCallLogs**](FilterCallLogs.md) |  | [optional] 
**sort** | [**SortCallLogs**](SortCallLogs.md) |  | [optional] 
**total** | **Integer** |  | [optional] 
**offset** | **Integer** |  | [optional] 
**limit** | **Integer** |  | [optional] 
**items** | [**Array&lt;CallLogFull&gt;**](CallLogFull.md) |  | [optional] 


