# SwaggerClient::SortIdCreatedAt

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**created_at** | **String** |  | [optional] 


