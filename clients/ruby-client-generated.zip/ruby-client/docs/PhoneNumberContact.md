# SwaggerClient::PhoneNumberContact

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** | Type of phone number, must be one of: home, business, mobile, fax, pager. Default is home. | [optional] 
**number** | **String** | Phone number, as entered. Does not need to be formatted in any particular way. Required. | [optional] 
**normalized** | **String** | Phone number in E.164 format. Read-only. | [optional] 


