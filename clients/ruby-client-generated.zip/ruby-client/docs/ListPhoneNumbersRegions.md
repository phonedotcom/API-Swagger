# SwaggerClient::ListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_by** | **Array&lt;String&gt;** |  | [optional] 
**filters** | [**FilterListPhoneNumbersRegions**](FilterListPhoneNumbersRegions.md) |  | [optional] 
**sort** | [**SortListPhoneNumbersRegions**](SortListPhoneNumbersRegions.md) |  | [optional] 
**total** | **Integer** |  | [optional] 
**offset** | **Integer** |  | [optional] 
**limit** | **Integer** |  | [optional] 
**items** | [**Array&lt;PhoneNumbersRegionFull&gt;**](PhoneNumbersRegionFull.md) |  | [optional] 


