# SwaggerClient::Recipient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **String** | Phone number that will receive the SMS message | [optional] 
**status** | **String** | Indicate the status of your SMS object. May be &#39;sent&#39;, &#39;received&#39;, &#39;queued&#39;, &#39;new&#39; ... | [optional] 


