# SwaggerClient::CreateDeviceParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Device Name | [optional] 
**lines** | **Array&lt;Object&gt;** | List of line objects | [optional] 


