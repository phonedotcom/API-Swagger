# SwaggerClient::Notification

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emails** | **Array&lt;String&gt;** | Array of email addresses | [optional] 
**sms** | **String** | Phone number capable of receiving SMS messages | [optional] 


