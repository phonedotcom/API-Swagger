# SwaggerClient::DeviceSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | ID | [optional] 
**name** | **String** | User-supplied name, otherwise NULL | [optional] 


