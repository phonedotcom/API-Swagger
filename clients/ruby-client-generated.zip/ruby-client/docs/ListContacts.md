# SwaggerClient::ListContacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdGroupIdUpdatedAtArray**](FilterIdGroupIdUpdatedAtArray.md) |  | [optional] 
**sort** | [**SortIdUpdatedAt**](SortIdUpdatedAt.md) |  | [optional] 
**total** | **Integer** |  | [optional] 
**offset** | **Integer** |  | [optional] 
**limit** | **Integer** |  | [optional] 
**items** | [**Array&lt;ContactFull&gt;**](ContactFull.md) |  | [optional] 


