# SwaggerClient::SortListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**internal** | **String** |  | [optional] 
**price** | **String** |  | [optional] 
**phone_number** | **String** |  | [optional] 


