# SwaggerClient::FilterListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country_code** | **String** |  | [optional] 
**npa** | **Integer** |  | [optional] 
**nxx** | **String** |  | [optional] 
**is_toll_free** | **String** |  | [optional] 
**city** | **String** |  | [optional] 
**province_postal_code** | **String** |  | [optional] 
**country_postal_code** | **String** |  | [optional] 


