
# MenuSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Integer Menu ID. Read-only. |  [optional]
**name** | **String** | Name. Required. Unique. |  [optional]



