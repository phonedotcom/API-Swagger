
# ListSms

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdDirectionFrom**](FilterIdDirectionFrom.md) |  |  [optional]
**sort** | [**SortIdCreatedAt**](SortIdCreatedAt.md) |  |  [optional]
**total** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**limit** | **Integer** |  |  [optional]
**items** | [**List&lt;SmsFull&gt;**](SmsFull.md) |  |  [optional]



