
# SortIdCreatedAt

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**createdAt** | **String** |  |  [optional]



