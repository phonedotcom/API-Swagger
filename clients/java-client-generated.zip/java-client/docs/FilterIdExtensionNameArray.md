
# FilterIdExtensionNameArray

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**extension** | **String** |  |  [optional]
**name** | **String** |  |  [optional]



