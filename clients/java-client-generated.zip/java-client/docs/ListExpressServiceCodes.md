
# ListExpressServiceCodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdArray**](FilterIdArray.md) |  |  [optional]
**sort** | [**List&lt;SortId&gt;**](SortId.md) |  |  [optional]
**total** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**limit** | **Integer** |  |  [optional]
**items** | [**List&lt;ExpressServiceCodeFull&gt;**](ExpressServiceCodeFull.md) |  |  [optional]



