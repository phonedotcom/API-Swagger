
# ContactAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name. Required. |  [optional]
**company** | **String** | Company name |  [optional]
**address** | [**Address**](Address.md) |  |  [optional]
**phone** | **String** | Phone number. Required. |  [optional]
**fax** | **String** | Fax number |  [optional]
**primaryEmail** | **String** | Primary email address. Required. |  [optional]
**alternateEmail** | **String** | Alternate email address |  [optional]



