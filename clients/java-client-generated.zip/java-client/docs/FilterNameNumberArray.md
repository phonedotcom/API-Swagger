
# FilterNameNumberArray

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**number** | **String** |  |  [optional]



