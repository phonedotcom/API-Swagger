
# ListGroups

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdNameArray**](FilterIdNameArray.md) |  |  [optional]
**sort** | [**SortIdName**](SortIdName.md) |  |  [optional]
**total** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**limit** | **Integer** |  |  [optional]
**items** | [**List&lt;GroupFull&gt;**](GroupFull.md) |  |  [optional]



