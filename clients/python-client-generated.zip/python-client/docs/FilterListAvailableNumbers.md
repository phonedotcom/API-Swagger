# FilterListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phone_number** | **str** |  | [optional] 
**country_code** | **str** |  | [optional] 
**npa** | **str** |  | [optional] 
**nxx** | **str** |  | [optional] 
**xxxx** | **str** |  | [optional] 
**city** | **str** |  | [optional] 
**province** | **str** |  | [optional] 
**country** | **str** |  | [optional] 
**price** | **str** |  | [optional] 
**category** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


