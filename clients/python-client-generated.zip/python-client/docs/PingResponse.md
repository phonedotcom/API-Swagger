# PingResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datetime** | **str** |  | [optional] 
**remote_ip** | **str** |  | [optional] 
**timestamp** | **int** |  | [optional] 
**user_agent** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


