# CallNotifications

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emails** | **list[str]** | Array of email addresses | [optional] 
**sms** | **str** | A phone number capable of receiving SMS messages | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


