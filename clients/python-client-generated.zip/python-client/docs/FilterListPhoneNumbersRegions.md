# FilterListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**country_code** | **str** |  | [optional] 
**npa** | **str** |  | [optional] 
**nxx** | **str** |  | [optional] 
**is_toll_free** | **str** |  | [optional] 
**city** | **str** |  | [optional] 
**province_postal_code** | **str** |  | [optional] 
**country_postal_code** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


