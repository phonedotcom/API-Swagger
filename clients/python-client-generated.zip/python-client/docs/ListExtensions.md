# ListExtensions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**FilterIdExtensionNameArray**](FilterIdExtensionNameArray.md) |  | [optional] 
**sort** | [**SortIdExtensionName**](SortIdExtensionName.md) |  | [optional] 
**total** | **int** |  | [optional] 
**offset** | **int** |  | [optional] 
**limit** | **int** |  | [optional] 
**items** | [**list[ExtensionFull]**](ExtensionFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


