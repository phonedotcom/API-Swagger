# SipAuthentication

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**host** | **str** | Hostname | [optional] 
**port** | **int** | Port number | [optional] 
**username** | **str** | Username. This is the ID of the device. | [optional] 
**password** | **str** | Password. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


