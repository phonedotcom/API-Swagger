# SWGRecipient

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **NSString*** | Phone number that will receive the SMS message | [optional] 
**status** | **NSString*** | Indicate the status of your SMS object. May be &#39;sent&#39;, &#39;received&#39;, &#39;queued&#39;, &#39;new&#39; ... | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


