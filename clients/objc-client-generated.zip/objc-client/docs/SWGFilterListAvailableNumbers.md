# SWGFilterListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phoneNumber** | **NSString*** |  | [optional] 
**countryCode** | **NSString*** |  | [optional] 
**npa** | **NSNumber*** |  | [optional] 
**nxx** | **NSString*** |  | [optional] 
**xxxx** | **NSString*** |  | [optional] 
**city** | **NSString*** |  | [optional] 
**province** | **NSString*** |  | [optional] 
**country** | **NSString*** |  | [optional] 
**price** | **NSString*** |  | [optional] 
**category** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


