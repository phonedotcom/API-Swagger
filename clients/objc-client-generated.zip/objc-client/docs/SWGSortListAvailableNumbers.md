# SWGSortListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**internal** | **NSString*** |  | [optional] 
**price** | **NSString*** |  | [optional] 
**phoneNumber** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


