# SWGAvailableNumbersFull

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**phoneNumber** | **NSString*** | Phone number, in E.164 format | [optional] 
**formatted** | **NSString*** | Human-readable formatted version of the phone number | [optional] 
**price** | **NSNumber*** | The one-time initial price for this number, in USD. Some numbers show REQUEST_QUOTE here. Please contact our sales department if you are interested in these numbers. | [optional] 
**isTollFree** | **NSNumber*** | Whether the number is toll-free | [optional] 
**countryCode** | **NSString*** | The international dialing prefix for this number. For US and Canadian numbers, for example, this will be \&quot;1\&quot;. | [optional] 
**npa** | **NSString*** | Area code (a.k.a. NPA). Included for North American numbers only. | [optional] 
**nxx** | **NSString*** | Second 3 digits (a.k.a. NXX). Included for North American numbers only. | [optional] 
**xxxx** | **NSString*** | Last 4 digits (a.k.a. XXXX). Included for North American numbers only. | [optional] 
**city** | **NSString*** | City with which this number is associated, if known. Otherwise NULL. | [optional] 
**province** | **NSString*** | State or Province with which this number is associated, if known. Postal Code. Otherwise NULL. | [optional] 
**country** | **NSString*** | Country with which this number is associated, if known. Otherwise NULL. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


