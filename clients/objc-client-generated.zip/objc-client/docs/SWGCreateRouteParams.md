# SWGCreateRouteParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **NSString*** | Name | [optional] 
**rules** | **NSArray&lt;NSObject*&gt;*** | Rule Sets | [optional] 
**extension** | **NSObject*** | Extension Reference | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


