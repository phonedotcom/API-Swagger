# SWGListExpressServiceCodes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**SWGFilterIdArray***](SWGFilterIdArray.md) |  | [optional] 
**sort** | [**NSArray&lt;SWGSortId&gt;***](SWGSortId.md) |  | [optional] 
**total** | **NSNumber*** |  | [optional] 
**offset** | **NSNumber*** |  | [optional] 
**limit** | **NSNumber*** |  | [optional] 
**items** | [**NSArray&lt;SWGExpressServiceCodeFull&gt;***](SWGExpressServiceCodeFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


