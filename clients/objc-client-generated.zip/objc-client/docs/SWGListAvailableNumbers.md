# SWGListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**SWGFilterListAvailableNumbers***](SWGFilterListAvailableNumbers.md) |  | [optional] 
**sort** | [**SWGSortListAvailableNumbers***](SWGSortListAvailableNumbers.md) |  | [optional] 
**total** | **NSNumber*** |  | [optional] 
**offset** | **NSNumber*** |  | [optional] 
**limit** | **NSNumber*** |  | [optional] 
**items** | [**NSArray&lt;SWGAvailableNumbersFull&gt;***](SWGAvailableNumbersFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


