# SWGListContacts

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**SWGFilterIdGroupIdUpdatedAtArray***](SWGFilterIdGroupIdUpdatedAtArray.md) |  | [optional] 
**sort** | [**SWGSortIdUpdatedAt***](SWGSortIdUpdatedAt.md) |  | [optional] 
**total** | **NSNumber*** |  | [optional] 
**offset** | **NSNumber*** |  | [optional] 
**limit** | **NSNumber*** |  | [optional] 
**items** | [**NSArray&lt;SWGContactFull&gt;***](SWGContactFull.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


