# SWGListPhoneNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**filters** | [**SWGFilterIdNamePhoneNumberArray***](SWGFilterIdNamePhoneNumberArray.md) |  | [optional] 
**sort** | [**SWGSortIdNamePhoneNumber***](SWGSortIdNamePhoneNumber.md) |  | [optional] 
**total** | **NSNumber*** |  | [optional] 
**offset** | **NSNumber*** |  | [optional] 
**limit** | **NSNumber*** |  | [optional] 
**items** | [**NSArray&lt;SWGPhoneNumberContact&gt;***](SWGPhoneNumberContact.md) | Array of Contact Phone Number Objects. See below for details. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


