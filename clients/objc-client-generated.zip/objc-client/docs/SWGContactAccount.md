# SWGContactAccount

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **NSString*** | Name. Required. | [optional] 
**company** | **NSString*** | Company name | [optional] 
**address** | [**SWGAddress***](SWGAddress.md) |  | [optional] 
**phone** | **NSString*** | Phone number. Required. | [optional] 
**fax** | **NSString*** | Fax number | [optional] 
**primaryEmail** | **NSString*** | Primary email address. Required. | [optional] 
**alternateEmail** | **NSString*** | Alternate email address | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


