# SWGNotification

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**emails** | **NSArray&lt;NSString*&gt;*** | Array of email addresses | [optional] 
**sms** | **NSString*** | Phone number capable of receiving SMS messages | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


