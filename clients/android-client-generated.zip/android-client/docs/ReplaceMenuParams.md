
# ReplaceMenuParams

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  |  [optional]
**greeting** | **Object** |  |  [optional]
**invalidKeypress** | **Object** |  |  [optional]
**allowExtensionDial** | **Boolean** |  |  [optional]
**keypressWaitTime** | **Integer** |  |  [optional]
**timeoutHandler** | **Object** |  |  [optional]
**options** | **List&lt;Object&gt;** |  |  [optional]



