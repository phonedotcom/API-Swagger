
# SortListAvailableNumbers

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**internal** | **String** |  |  [optional]
**price** | **String** |  |  [optional]
**phoneNumber** | **String** |  |  [optional]



