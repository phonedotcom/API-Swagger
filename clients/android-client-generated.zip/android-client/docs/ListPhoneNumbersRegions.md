
# ListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**groupBy** | **List&lt;String&gt;** |  |  [optional]
**filters** | [**FilterListPhoneNumbersRegions**](FilterListPhoneNumbersRegions.md) |  |  [optional]
**sort** | [**SortListPhoneNumbersRegions**](SortListPhoneNumbersRegions.md) |  |  [optional]
**total** | **Integer** |  |  [optional]
**offset** | **Integer** |  |  [optional]
**limit** | **Integer** |  |  [optional]
**items** | [**List&lt;PhoneNumbersRegionFull&gt;**](PhoneNumbersRegionFull.md) |  |  [optional]



