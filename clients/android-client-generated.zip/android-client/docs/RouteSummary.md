
# RouteSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Integer ID. Read-only. |  [optional]
**name** | **String** | Name |  [optional]



