
# SortIdUpdatedAt

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  |  [optional]
**updatedAt** | **String** |  |  [optional]



