
# FilterListPhoneNumbersRegions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**countryCode** | **String** |  |  [optional]
**npa** | **Integer** |  |  [optional]
**nxx** | **String** |  |  [optional]
**isTollFree** | **String** |  |  [optional]
**city** | **String** |  |  [optional]
**provincePostalCode** | **String** |  |  [optional]
**countryPostalCode** | **String** |  |  [optional]



