# IO.Swagger.Model.CreateRouteParams
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Name** | **string** | Name | [optional] 
**Rules** | **List&lt;Object&gt;** | Rule Sets | [optional] 
**Extension** | **Object** | Extension Reference | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

