# IO.Swagger.Model.CallerIdFull
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Number** | **string** | Phone number, in E.164 format | [optional] 
**Name** | **string** | Name you have supplied for this number | [optional] 
**Type** | **string** | Type of Caller ID. account means this number is registered to your account, and extra refers to extra numbers which you have authorized, which are not managed under Phone.com. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

