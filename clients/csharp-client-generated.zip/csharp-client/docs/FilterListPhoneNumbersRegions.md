# IO.Swagger.Model.FilterListPhoneNumbersRegions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CountryCode** | **string** |  | [optional] 
**Npa** | **int?** |  | [optional] 
**Nxx** | **string** |  | [optional] 
**IsTollFree** | **string** |  | [optional] 
**City** | **string** |  | [optional] 
**ProvincePostalCode** | **string** |  | [optional] 
**CountryPostalCode** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

