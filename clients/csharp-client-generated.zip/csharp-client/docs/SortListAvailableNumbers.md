# IO.Swagger.Model.SortListAvailableNumbers
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_Internal** | **string** |  | [optional] 
**Price** | **string** |  | [optional] 
**PhoneNumber** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

